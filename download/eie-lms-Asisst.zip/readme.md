EiE Assist Addon
================
## EiE LMS의 불편한 점을 보완해줍니다.
----
#### Download : [다운로드 링크](https://github.com/explainpark101/eie-assist-extension/raw/main/download/eie-lms-Asisst.zip)
----
#### Features
 - 대시보드에 검색기능 추가
 - 수업관리 > 수업목록 빠른 검색
 - 수업관리 > 수업목록 자동 오름차순 정렬